class Animal < ApplicationRecord
end
